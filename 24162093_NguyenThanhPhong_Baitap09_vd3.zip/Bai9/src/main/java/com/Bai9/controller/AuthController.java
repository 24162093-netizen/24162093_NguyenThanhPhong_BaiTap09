package com.Bai9.controller;

import jakarta.validation.Valid;

import lombok.RequiredArgsConstructor;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.Bai9.dto.*;
import com.Bai9.service.AuthService;
import com.Bai9.service.OtpService;

@Controller
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;
    private final OtpService otpService;

    // =========================
    // LOGIN
    // =========================

    @GetMapping("/login")
    public String login() {
        return "auth/login";
    }

    // =========================
    // REGISTER - GET
    // =========================

    @GetMapping("/register")
    public String register(Model model) {

        model.addAttribute(
            "registerDTO",
            new RegisterDTO()
        );

        return "auth/register";
    }

    // =========================
    // REGISTER - POST
    // =========================

    @PostMapping("/register")
    public String register(
            @Valid @ModelAttribute("registerDTO") RegisterDTO dto,
            BindingResult result) {

        // Lỗi validate form
        if (result.hasErrors()) {
            return "auth/register";
        }

        try {

            // Kiểm tra username/email
            // Tạo user enabled = false
            // Gửi OTP
            authService.register(dto);

            // Đăng ký thành công
            // Chuyển sang trang nhập OTP
            return "redirect:/verify-otp?email="
                    + dto.getEmail();

        } catch (IllegalArgumentException e) {

            result.reject(
                "register.error",
                e.getMessage()
            );

            return "auth/register";
        }
    }

    // =========================
    // VERIFY OTP - GET
    // =========================

    @GetMapping("/verify-otp")
    public String verifyPage(
            @RequestParam(required = false) String email,
            Model model) {

        VerifyOtpDTO dto = new VerifyOtpDTO();

        dto.setEmail(email);

        model.addAttribute(
            "verifyOtpDTO",
            dto
        );

        return "auth/verify-otp";
    }

    // =========================
    // VERIFY OTP - POST
    // =========================

    @PostMapping("/verify-otp")
    public String verify(
            @Valid @ModelAttribute("verifyOtpDTO") VerifyOtpDTO dto,
            BindingResult result,
            RedirectAttributes redirect) {

        if (result.hasErrors()) {
            return "auth/verify-otp";
        }

        boolean verified =
                authService.verifyRegister(
                    dto.getEmail(),
                    dto.getOtp()
                );

        if (!verified) {

            result.reject(
                "otp.error",
                "OTP không hợp lệ, hết hạn hoặc đã quá số lần thử."
            );

            return "auth/verify-otp";
        }

        // Xác thực thành công
        redirect.addFlashAttribute(
            "success",
            "Xác thực tài khoản thành công. Hãy đăng nhập."
        );

        // Quay về trang Login
        return "redirect:/login";
    }

    // =========================
    // RESEND REGISTER OTP
    // =========================

    @PostMapping("/resend-register-otp")
    public String resend(
            @RequestParam String email,
            RedirectAttributes redirect) {

        otpService.sendRegisterOtp(email);

        redirect.addFlashAttribute(
            "success",
            "Đã gửi lại OTP."
        );

        return "redirect:/verify-otp?email="
                + email;
    }

    // =========================
    // FORGOT PASSWORD - GET
    // =========================

    @GetMapping("/forgot-password")
    public String forgot(Model model) {

        model.addAttribute(
            "forgotPasswordDTO",
            new ForgotPasswordDTO()
        );

        return "auth/forgot-password";
    }

    // =========================
    // FORGOT PASSWORD - POST
    // =========================

    @PostMapping("/forgot-password")
    public String forgot(
            @Valid @ModelAttribute("forgotPasswordDTO") ForgotPasswordDTO dto,
            BindingResult result,
            RedirectAttributes redirect) {

        if (result.hasErrors()) {
            return "auth/forgot-password";
        }

        try {

            authService.forgotPassword(
                dto.getEmail()
            );

            redirect.addFlashAttribute(
                "email",
                dto.getEmail()
            );

            redirect.addFlashAttribute(
                "success",
                "OTP đã được gửi."
            );

            return "redirect:/reset-password";

        } catch (IllegalArgumentException e) {

            result.reject(
                "forgot.error",
                e.getMessage()
            );

            return "auth/forgot-password";
        }
    }

    // =========================
    // RESET PASSWORD - GET
    // =========================

    @GetMapping("/reset-password")
    public String reset(Model model) {

        ResetPasswordDTO dto =
                new ResetPasswordDTO();

        Object email =
                model.asMap().get("email");

        if (email != null) {
            dto.setEmail(email.toString());
        }

        model.addAttribute(
            "resetPasswordDTO",
            dto
        );

        return "auth/reset-password";
    }

    // =========================
    // RESET PASSWORD - POST
    // =========================

    @PostMapping("/reset-password")
    public String reset(
            @Valid @ModelAttribute("resetPasswordDTO") ResetPasswordDTO dto,
            BindingResult result,
            @RequestParam String otp,
            RedirectAttributes redirect) {

        if (!dto.getPassword()
                .equals(dto.getConfirmPassword())) {

            result.reject(
                "password.error",
                "Mật khẩu xác nhận không đúng."
            );
        }

        if (result.hasErrors()) {
            return "auth/reset-password";
        }

        if (!authService.verifyResetOtp(
                dto.getEmail(),
                otp)) {

            result.reject(
                "otp.error",
                "OTP không hợp lệ hoặc đã hết hạn."
            );

            return "auth/reset-password";
        }

        authService.resetPassword(
            dto.getEmail(),
            dto.getPassword()
        );

        redirect.addFlashAttribute(
            "success",
            "Đổi mật khẩu thành công. Hãy đăng nhập."
        );

        return "redirect:/login";
    }
}