package com.Bai9.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.Bai9.service.ProductService;
import com.Bai9.service.UserService;

@Controller
public class DashboardController {

    private final UserService userService;
    private final ProductService productService;

    public DashboardController(
            UserService userService,
            ProductService productService) {

        this.userService = userService;
        this.productService = productService;
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {

        long totalUsers = userService.countUsers();
        long totalProducts = productService.countProducts();

        model.addAttribute("totalUsers", totalUsers);
        model.addAttribute("totalProducts", totalProducts);

        return "dashboard";
    }
}