package com.Bai9.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.Bai9.service.ProductService;
import com.Bai9.service.UserService;

@Controller
public class HomeController {

    private final UserService userService;
    private final ProductService productService;

    public HomeController(
            UserService userService,
            ProductService productService) {

        this.userService = userService;
        this.productService = productService;
    }

    @GetMapping("/")
    public String home(Model model) {

        long totalUsers = userService.countUsers();
        long totalProducts = productService.countProducts();

        model.addAttribute("totalUsers", totalUsers);
        model.addAttribute("totalProducts", totalProducts);

        return "dashboard";
    }
}