package com.Bai9.controller;

import lombok.RequiredArgsConstructor;

import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.Bai9.dto.ProductDTO;
import com.Bai9.repository.UserRepository;
import com.Bai9.service.ProductService;

@Controller
@RequiredArgsConstructor
@RequestMapping("/admin/products")
public class ProductController {

    private final ProductService productService;
    private final UserRepository userRepository;


    // =========================================================
    // DANH SÁCH PRODUCT
    // =========================================================

    @GetMapping
    public String list(
            @RequestParam(defaultValue = "") String keyword,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "5") int size,
            Model model) {

        Page<ProductDTO> productPage =
                productService.findAll(
                        keyword,
                        page,
                        size
                );

        model.addAttribute(
                "productPage",
                productPage
        );

        model.addAttribute(
                "keyword",
                keyword
        );

        model.addAttribute(
                "page",
                page
        );

        model.addAttribute(
                "size",
                size
        );

        return "admin/products";
    }


    // =========================================================
    // HIỂN THỊ FORM THÊM PRODUCT
    // =========================================================

    @GetMapping("/add")
    public String add(Model model) {

        ProductDTO productDTO = new ProductDTO();

        model.addAttribute(
                "productDTO",
                productDTO
        );

        // Danh sách User để chọn người sở hữu Product
        model.addAttribute(
                "users",
                userRepository.findAll()
        );

        return "admin/product-form";
    }


    // =========================================================
    // XỬ LÝ THÊM PRODUCT
    // =========================================================

    @PostMapping("/add")
    public String add(
            @ModelAttribute("productDTO") ProductDTO dto,

            @RequestParam(
                    value = "image",
                    required = false
            )
            MultipartFile image) {

        productService.create(
                dto,
                image
        );

        return "redirect:/admin/products";
    }


    // =========================================================
    // HIỂN THỊ FORM SỬA PRODUCT
    // =========================================================

    @GetMapping("/edit/{id}")
    public String edit(
            @PathVariable Long id,
            Model model) {

        ProductDTO productDTO =
                productService.findById(id);

        model.addAttribute(
                "productDTO",
                productDTO
        );

        // Quan trọng:
        // Khi sửa Product vẫn phải truyền danh sách User
        // để dropdown User hiển thị đúng.
        model.addAttribute(
                "users",
                userRepository.findAll()
        );

        return "admin/product-form";
    }


    // =========================================================
    // XỬ LÝ SỬA PRODUCT
    // =========================================================

    @PostMapping("/edit/{id}")
    public String edit(
            @PathVariable Long id,

            @ModelAttribute("productDTO")
            ProductDTO dto,

            @RequestParam(
                    value = "image",
                    required = false
            )
            MultipartFile image) {

        productService.update(
                id,
                dto,
                image
        );

        return "redirect:/admin/products";
    }


    // =========================================================
    // XÓA PRODUCT
    // =========================================================

    @PostMapping("/delete/{id}")
    public String delete(
            @PathVariable Long id) {

        productService.delete(id);

        return "redirect:/admin/products";
    }
}