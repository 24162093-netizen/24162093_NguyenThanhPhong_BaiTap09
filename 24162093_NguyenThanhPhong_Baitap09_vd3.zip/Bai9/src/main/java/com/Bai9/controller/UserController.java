package com.Bai9.controller;

import lombok.RequiredArgsConstructor;

import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.Bai9.dto.UserDTO;
import com.Bai9.service.UserService;

@Controller
@RequiredArgsConstructor
@RequestMapping("/admin/users")
public class UserController {

    private final UserService userService;

    @GetMapping
    public String list(
            @RequestParam(defaultValue = "") String keyword,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "5") int size,
            Model model) {

        Page<UserDTO> userPage =
                userService.findAll(keyword, page, size);

        model.addAttribute("userPage", userPage);
        model.addAttribute("keyword", keyword);
        model.addAttribute("page", page);
        model.addAttribute("size", size);

        return "admin/users";
    }

    @GetMapping("/add")
    public String add(Model model) {

        model.addAttribute("userDTO", new UserDTO());

        return "admin/user-form";
    }

    @PostMapping("/add")
    public String add(
            @ModelAttribute("userDTO") UserDTO dto) {

        userService.create(dto);

        return "redirect:/admin/users";
    }

    @GetMapping("/edit/{id}")
    public String edit(
            @PathVariable Long id,
            Model model) {

        model.addAttribute(
                "userDTO",
                userService.findById(id)
        );

        return "admin/user-form";
    }

    @PostMapping("/edit/{id}")
    public String edit(
            @PathVariable Long id,
            @ModelAttribute("userDTO") UserDTO dto) {

        userService.update(id, dto);

        return "redirect:/admin/users";
    }

    @GetMapping("/delete/{id}")
    public String delete(
            @PathVariable Long id) {

        userService.delete(id);

        return "redirect:/admin/users";
    }
}