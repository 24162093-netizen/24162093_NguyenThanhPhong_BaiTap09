package com.Bai9.service.impl;

import lombok.RequiredArgsConstructor;

import org.springframework.data.domain.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.Bai9.dto.UserDTO;
import com.Bai9.entity.Role;
import com.Bai9.entity.User;
import com.Bai9.mapper.UserMapper;
import com.Bai9.repository.RoleRepository;
import com.Bai9.repository.UserRepository;
import com.Bai9.service.UserService;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final UserMapper mapper;
    private final PasswordEncoder passwordEncoder;

    @Override
    @Transactional(readOnly = true)
    public Page<UserDTO> findAll(String keyword, int page, int size) {

        Pageable pageable = PageRequest.of(
            Math.max(page, 0),
            Math.max(size, 1),
            Sort.by(Sort.Direction.DESC, "id")
        );

        return userRepository
                .search(
                    keyword == null ? "" : keyword,
                    pageable
                )
                .map(user -> {

                    UserDTO dto = mapper.toDTO(user);

                    dto.setProductCount(
                        userRepository.countProductsByUserId(
                            user.getId()
                        )
                    );

                    return dto;
                });
    }

    @Override
    @Transactional(readOnly = true)
    public UserDTO findById(Long id) {

        User user = userRepository.findById(id)
                .orElseThrow(() ->
                    new IllegalArgumentException(
                        "User không tồn tại"
                    )
                );

        return mapper.toDTO(user);
    }

    @Override
    @Transactional
    public UserDTO create(UserDTO dto) {

        if (userRepository.existsByUsername(dto.getUsername())) {
            throw new IllegalArgumentException(
                "Username đã tồn tại"
            );
        }

        if (userRepository.existsByEmail(dto.getEmail())) {
            throw new IllegalArgumentException(
                "Email đã tồn tại"
            );
        }

        Role role = roleRepository
                .findByNameIgnoreCase(dto.getRoleName())
                .orElseThrow(() ->
                    new IllegalArgumentException(
                        "Role không tồn tại"
                    )
                );

        User user = mapper.toEntity(dto);

        user.setRole(role);

        user.setPassword(
            passwordEncoder.encode("123456")
        );

        user.setEnabled(dto.isEnabled());

        return mapper.toDTO(
            userRepository.save(user)
        );
    }

    @Override
    @Transactional
    public UserDTO update(Long id, UserDTO dto) {

        User user = userRepository.findById(id)
                .orElseThrow(() ->
                    new IllegalArgumentException(
                        "User không tồn tại"
                    )
                );

        if (!user.getUsername().equals(dto.getUsername())
                && userRepository.existsByUsername(
                    dto.getUsername()
                )) {

            throw new IllegalArgumentException(
                "Username đã tồn tại"
            );
        }

        if (!user.getEmail().equals(dto.getEmail())
                && userRepository.existsByEmail(
                    dto.getEmail()
                )) {

            throw new IllegalArgumentException(
                "Email đã tồn tại"
            );
        }

        Role role = roleRepository
                .findByNameIgnoreCase(dto.getRoleName())
                .orElseThrow(() ->
                    new IllegalArgumentException(
                        "Role không tồn tại"
                    )
                );

        user.setUsername(dto.getUsername());
        user.setEmail(dto.getEmail());
        user.setFullName(dto.getFullName());
        user.setEnabled(dto.isEnabled());
        user.setRole(role);

        return mapper.toDTO(
            userRepository.save(user)
        );
    }

    @Override
    @Transactional
    public void delete(Long id) {

        User user = userRepository.findById(id)
                .orElseThrow(() ->
                    new IllegalArgumentException(
                        "User không tồn tại"
                    )
                );

        userRepository.delete(user);
    }

    @Override
    @Transactional(readOnly = true)
    public long countUsers() {

        return userRepository.count();
    }

    @Override
    @Transactional(readOnly = true)
    public long countProducts(Long userId) {

        return userRepository.countProductsByUserId(userId);
    }
}