package com.Bai9.service.impl;

import lombok.RequiredArgsConstructor;

import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.Bai9.dto.ProductDTO;
import com.Bai9.entity.Product;
import com.Bai9.entity.User;
import com.Bai9.mapper.ProductMapper;
import com.Bai9.repository.ProductRepository;
import com.Bai9.repository.UserRepository;
import com.Bai9.service.CloudinaryService;
import com.Bai9.service.CloudinaryUploadResult;
import com.Bai9.service.ProductService;

@Service
@RequiredArgsConstructor
public class ProductServiceImpl implements ProductService {

    private final ProductRepository productRepository;
    private final UserRepository userRepository;
    private final ProductMapper mapper;
    private final CloudinaryService cloudinaryService;


    // =========================================================
    // DANH SÁCH PRODUCT
    // =========================================================

    @Override
    @Transactional(readOnly = true)
    public Page<ProductDTO> findAll(
            String keyword,
            int page,
            int size) {

        Pageable pageable = PageRequest.of(
                Math.max(page, 0),
                Math.max(size, 1),
                Sort.by(
                        Sort.Direction.DESC,
                        "id"
                )
        );

        return productRepository
                .search(
                        keyword == null ? "" : keyword,
                        pageable
                )
                .map(mapper::toDTO);
    }


    // =========================================================
    // TÌM PRODUCT THEO ID
    // =========================================================

    @Override
    @Transactional(readOnly = true)
    public ProductDTO findById(Long id) {

        Product product =
                productRepository.findById(id)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "Product không tồn tại"
                                )
                        );

        return mapper.toDTO(product);
    }


    // =========================================================
    // THÊM PRODUCT
    // =========================================================

    @Override
    @Transactional
    public ProductDTO create(
            ProductDTO dto,
            MultipartFile image) {

        // Tìm User sở hữu Product
        User user =
                userRepository.findById(dto.getUserId())
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "User không tồn tại"
                                )
                        );

        // Chuyển DTO -> Entity
        Product product =
                mapper.toEntity(dto);

        // Gán User cho Product
        product.setUser(user);

        // Upload ảnh nếu có
        if (image != null && !image.isEmpty()) {

            CloudinaryUploadResult result =
                    cloudinaryService.upload(image);

            product.setImageUrl(
                    result.url()
                    + "|"
                    + result.publicId()
            );
        }

        return mapper.toDTO(
                productRepository.save(product)
        );
    }


    // =========================================================
    // SỬA PRODUCT
    // =========================================================

    @Override
    @Transactional
    public ProductDTO update(
            Long id,
            ProductDTO dto,
            MultipartFile image) {

        // Tìm Product
        Product product =
                productRepository.findById(id)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "Product không tồn tại"
                                )
                        );

        // Cập nhật thông tin Product
        product.setName(dto.getName());
        product.setDescription(dto.getDescription());
        product.setPrice(dto.getPrice());


        // -----------------------------------------------------
        // CẬP NHẬT USER SỞ HỮU PRODUCT
        // -----------------------------------------------------

        User user =
                userRepository.findById(dto.getUserId())
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "User không tồn tại"
                                )
                        );

        product.setUser(user);


        // -----------------------------------------------------
        // CẬP NHẬT ẢNH
        // -----------------------------------------------------

        if (image != null && !image.isEmpty()) {

            String oldImage =
                    product.getImageUrl();

            // Xóa ảnh cũ trên Cloudinary
            if (oldImage != null
                    && oldImage.contains("|")) {

                String oldPublicId =
                        oldImage.substring(
                                oldImage.indexOf("|") + 1
                        );

                cloudinaryService.delete(
                        oldPublicId
                );
            }

            // Upload ảnh mới
            CloudinaryUploadResult result =
                    cloudinaryService.upload(image);

            product.setImageUrl(
                    result.url()
                    + "|"
                    + result.publicId()
            );
        }

        return mapper.toDTO(
                productRepository.save(product)
        );
    }


    // =========================================================
    // XÓA PRODUCT
    // =========================================================

    @Override
    @Transactional
    public void delete(Long id) {

        Product product =
                productRepository.findById(id)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "Product không tồn tại"
                                )
                        );

        String image =
                product.getImageUrl();

        // Xóa ảnh trên Cloudinary
        if (image != null
                && image.contains("|")) {

            String publicId =
                    image.substring(
                            image.indexOf("|") + 1
                    );

            cloudinaryService.delete(
                    publicId
            );
        }

        // Xóa Product
        productRepository.delete(product);
    }


    // =========================================================
    // ĐẾM TỔNG PRODUCT
    // =========================================================

    @Override
    @Transactional(readOnly = true)
    public long countProducts() {

        return productRepository.count();
    }


    // =========================================================
    // ĐẾM PRODUCT THEO USER
    // =========================================================

    @Override
    @Transactional(readOnly = true)
    public long countByUser(Long userId) {

        return productRepository.countByUserId(
                userId
        );
    }
}