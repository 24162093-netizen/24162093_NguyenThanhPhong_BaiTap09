package com.Bai9.service;

public interface EmailService {

    void sendOtp(String email, String otp, String subject);
}