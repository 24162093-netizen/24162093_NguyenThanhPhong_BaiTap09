package com.Bai9.service.impl;

import lombok.RequiredArgsConstructor;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.Bai9.dto.RegisterDTO;
import com.Bai9.entity.Role;
import com.Bai9.entity.User;
import com.Bai9.repository.RoleRepository;
import com.Bai9.repository.UserRepository;
import com.Bai9.service.AuthService;
import com.Bai9.service.OtpService;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;
    private final OtpService otpService;

    @Override
    @Transactional
    public void register(RegisterDTO dto) {

        if (userRepository.existsByUsername(dto.getUsername())) {
            throw new IllegalArgumentException(
                "Username đã tồn tại"
            );
        }

        if (userRepository.existsByEmail(dto.getEmail())) {
            throw new IllegalArgumentException(
                "Email đã tồn tại"
            );
        }

        if (!dto.getPassword()
                .equals(dto.getConfirmPassword())) {

            throw new IllegalArgumentException(
                "Mật khẩu xác nhận không đúng"
            );
        }

        Role role = roleRepository
            .findByNameIgnoreCase("ROLE_USER")
            .orElseThrow(() ->
                new IllegalStateException(
                    "Chưa có ROLE_USER"
                )
            );

        User user = User.builder()
                .username(dto.getUsername())
                .email(dto.getEmail())
                .password(
                    passwordEncoder.encode(
                        dto.getPassword()
                    )
                )
                .fullName(dto.getFullName())
                .enabled(false)
                .role(role)
                .build();

        userRepository.save(user);

        otpService.sendRegisterOtp(
            dto.getEmail()
        );
    }

    @Override
    @Transactional
    public boolean verifyRegister(
            String email,
            String otp) {

        boolean ok =
            otpService.verifyRegisterOtp(
                email,
                otp
            );

        if (!ok) {
            return false;
        }

        User user = userRepository
            .findByEmail(email)
            .orElseThrow(() ->
                new IllegalArgumentException(
                    "User không tồn tại"
                )
            );

        user.setEnabled(true);

        return true;
    }

    @Override
    @Transactional
    public void forgotPassword(String email) {

        if (!userRepository.existsByEmail(email)) {
            throw new IllegalArgumentException(
                "Email không tồn tại"
            );
        }

        otpService.sendResetPasswordOtp(email);
    }

    @Override
    public boolean verifyResetOtp(
            String email,
            String otp) {

        return otpService.verifyResetPasswordOtp(
            email,
            otp
        );
    }

    @Override
    @Transactional
    public void resetPassword(
            String email,
            String password) {

        User user = userRepository
            .findByEmail(email)
            .orElseThrow(() ->
                new IllegalArgumentException(
                    "Email không tồn tại"
                )
            );

        user.setPassword(
            passwordEncoder.encode(password)
        );
    }
}