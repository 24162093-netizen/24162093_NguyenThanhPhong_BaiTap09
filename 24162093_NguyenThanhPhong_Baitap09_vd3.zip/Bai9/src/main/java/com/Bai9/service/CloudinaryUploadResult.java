package com.Bai9.service;

public record CloudinaryUploadResult(
        String url,
        String publicId
) {
}