package com.Bai9.repository;

import org.springframework.data.domain.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

import com.Bai9.entity.User;

import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByUsername(String username);

    Optional<User> findByEmail(String email);
    
    Optional<User> findByUsernameOrEmail(
            String username,
            String email
    );

    boolean existsByUsername(String username);

    boolean existsByEmail(String email);

    @Query("""
        select u from User u
        where lower(u.username) like lower(concat('%', :keyword, '%'))
        or lower(u.email) like lower(concat('%', :keyword, '%'))
        or lower(u.fullName) like lower(concat('%', :keyword, '%'))
        """)
    Page<User> search(
        @Param("keyword") String keyword,
        Pageable pageable
    );

    @Query("select count(p) from Product p where p.user.id = :userId")
    long countProductsByUserId(@Param("userId") Long userId);

    @Query("""
        select u.id as id, count(p.id) as productCount
        from User u
        left join u.products p
        group by u.id
        """)
    java.util.List<Object[]> countProductsForUsers();
}