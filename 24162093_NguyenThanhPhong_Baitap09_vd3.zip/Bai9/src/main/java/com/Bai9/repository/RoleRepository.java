package com.Bai9.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Bai9.entity.Role;

import java.util.Optional;

public interface RoleRepository extends JpaRepository<Role, Long> {

    Optional<Role> findByNameIgnoreCase(String name);
}