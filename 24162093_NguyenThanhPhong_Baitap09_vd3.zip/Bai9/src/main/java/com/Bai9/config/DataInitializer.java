package com.Bai9.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.Bai9.entity.Role;
import com.Bai9.entity.User;
import com.Bai9.repository.RoleRepository;
import com.Bai9.repository.UserRepository;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner initData(
            RoleRepository roles,
            UserRepository users,
            PasswordEncoder encoder,
            @Value("${ADMIN_EMAIL:admin@gmail.com}") String adminEmail,
            @Value("${ADMIN_PASSWORD:123456}") String adminPassword) {

        return args -> {

            // =========================
            // ROLE USER
            // =========================
            Role userRole = roles.findByNameIgnoreCase("ROLE_USER")
                    .orElseGet(() ->
                        roles.save(new Role("ROLE_USER"))
                    );

            // =========================
            // ROLE ADMIN
            // =========================
            Role adminRole = roles.findByNameIgnoreCase("ROLE_ADMIN")
                    .orElseGet(() ->
                        roles.save(new Role("ROLE_ADMIN"))
                    );

            // =========================
            // TẠO ADMIN
            // =========================
            if (users.findByUsername("admin").isEmpty()) {

                User admin = new User();

                admin.setUsername("admin");
                admin.setEmail(adminEmail.toLowerCase());
                admin.setFullName("System Administrator");
                admin.setPassword(encoder.encode(adminPassword));
                admin.setImages("/images/user.png");
                admin.setRole(adminRole);
                admin.setEnabled(true);

                users.save(admin);
            }

            // =========================
            // TẠO USER MẪU
            // =========================
            if (users.findByUsername("user01").isEmpty()) {

                User user = new User();

                user.setUsername("user01");
                user.setEmail("user01@gmail.com");
                user.setPassword(encoder.encode("123456"));
                user.setFullName("Nguyễn Hữu Trung");
                user.setImages("/images/user.png");
                user.setRole(userRole);
                user.setEnabled(true);

                users.save(user);
            }
        };
    }
}