package com.Bai9.controller;

import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.Bai9.security.CustomUserDetails;

@Controller
public class HomeController {

    @GetMapping("/")
    public String home(
            Authentication authentication,
            Model model) {

        if (authentication != null
                && authentication.getPrincipal() instanceof CustomUserDetails) {

            CustomUserDetails user =
                    (CustomUserDetails) authentication.getPrincipal();

            model.addAttribute("fullName", user.getFullName());
            model.addAttribute("images", user.getImages());
        }

        return "home";
    }
}