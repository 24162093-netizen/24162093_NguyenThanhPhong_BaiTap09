package com.Bai9.controller;

import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.Bai9.dto.UserDTO;
import com.Bai9.security.CustomUserDetails;
import com.Bai9.service.UserService;

@Controller
public class DashboardController {

    private final UserService userService;

    public DashboardController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/dashboard")
    public String dashboard(
            Authentication authentication,
            Model model) {

        CustomUserDetails principal =
                (CustomUserDetails) authentication.getPrincipal();

        UserDTO user =
                userService.findById(principal.getId());

        model.addAttribute("user", user);

        return "dashboard";
    }
}