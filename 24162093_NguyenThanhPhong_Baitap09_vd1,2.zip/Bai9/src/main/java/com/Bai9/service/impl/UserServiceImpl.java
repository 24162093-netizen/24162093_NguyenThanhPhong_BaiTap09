package com.Bai9.service.impl;

import org.springframework.stereotype.Service;

import com.Bai9.dto.UserDTO;
import com.Bai9.entity.User;
import com.Bai9.mapper.UserMapper;
import com.Bai9.repository.UserRepository;
import com.Bai9.service.UserService;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;

    private final UserMapper userMapper;

    public UserServiceImpl(
            UserRepository userRepository,
            UserMapper userMapper) {

        this.userRepository = userRepository;
        this.userMapper = userMapper;
    }

    @Override
    public UserDTO findById(Long id) {

        User user = userRepository
                .findById(id)
                .orElseThrow();

        return userMapper.toDTO(user);
    }
}