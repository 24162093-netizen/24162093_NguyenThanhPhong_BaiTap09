package com.Bai9.service;

import com.Bai9.dto.UserDTO;

public interface UserService {

    UserDTO findById(Long id);

}