package com.Bai9.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.Bai9.entity.Role;
import com.Bai9.entity.User;
import com.Bai9.repository.RoleRepository;
import com.Bai9.repository.UserRepository;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner initData(
            RoleRepository roles,
            UserRepository users,
            PasswordEncoder encoder,
            @Value("${ADMIN_EMAIL:admin@gmail.com}") String adminEmail,
            @Value("${ADMIN_PASSWORD:123456}") String adminPassword) {

        return args -> {

            Role userRole = roles.findByNameIgnoreCase("USER")
                    .orElseGet(() ->
                        roles.save(new Role("USER"))
                    );

            Role adminRole = roles.findByNameIgnoreCase("ADMIN")
                    .orElseGet(() ->
                        roles.save(new Role("ADMIN"))
                    );

            if (!users.existsByEmailIgnoreCase(adminEmail)) {

                User admin = new User();

                admin.setUsername("admin");
                admin.setEmail(adminEmail.toLowerCase());
                admin.setFullName("System Administrator");
                admin.setPassword(encoder.encode(adminPassword));
                admin.setRole(adminRole);
                admin.setEnabled(true);
                admin.setImages("/images/user.png");
                users.save(admin);
            }
        };
    }
}