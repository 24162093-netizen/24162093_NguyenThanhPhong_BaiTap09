package com.Bai9.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Bai9.entity.Role;

public interface RoleRepository extends JpaRepository<Role, Long> {

    Optional<Role> findByName(String name);

    Optional<Role> findByNameIgnoreCase(String name);
}