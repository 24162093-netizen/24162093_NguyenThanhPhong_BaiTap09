package com.Bai9.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.Bai9.dto.UserDTO;
import com.Bai9.entity.User;

@Mapper(componentModel = "spring")
public interface UserMapper {

    @Mapping(target = "roleName", source = "role.name")
    UserDTO toDTO(User user);
}